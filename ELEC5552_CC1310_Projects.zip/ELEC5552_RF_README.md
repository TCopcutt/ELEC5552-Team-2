# CC1310 RadioFrequency project files README
---
ELEC5552 Project 2 Team 2
This project files are for CC1310_LAUNCHXL lauchpad 

-------------------------
File purpose
tirtos_builds_CC1310_LAUNCHXL_release_ccs folder contains the reference build project, must import and build in CCS workspace before importing other projects
targetConfigs folder contains device model setting and connnection setting

# CC1310 RadioFrequency projects, no debugging console outputs
rfPacketRx_CC1310_LAUNCHXL_tirtos_ccs_922MHz no_output
rfPacketTx_CC1310_LAUNCHXL_tirtos_ccs_922MHz_no_output
rfPacketTx_CC1310_LAUNCHXL_tirtos_ccs_434MHz_no_output
rfPacketRx_CC1310_LAUNCHXL_tirtos_ccs_434MHz_no_output

# CC1310 RadioFrequency projects, packet content is shown in debugging console 
rfPacketTx_CC1310_LAUNCHXL_tirtos_ccs_922MHz_with_output
rfPacketTx_CC1310_LAUNCHXL_tirtos_ccs_434MHz_with_output
rfPacketRx_CC1310_LAUNCHXL_tirtos_ccs_434MHz_with_output
rfPacketRx_CC1310_LAUNCHXL_tirtos_ccs_922MHz_with_output

Succeeded connection test of Target Configuration.log contains the log infomation when the test connection is suceeded with correct targetConfigs setting
-------------------------
Detailed Parameters is described in the ELEC5552_README.md file in each project folder
There is also the CSS_README.md files which is the original README from the CCS example project